<!DOCTYPE html>
<html>
<head>
  <title>The page you were looking for doesn't exist</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    img {
      display: block;
      width: 500px;
      margin: 130px auto 30px;
    }

    h1 {
      font-size: 28px;
      font-family: Cerebri Sans, Helvetica, Arial, sans-serif;
      text-align: center;
      font-weight: bold;
      line-height: 1.5;
    }

    p {
      font-family: "PT Mono", monospace;
      font-size: 16px;
      text-align: center;
      max-width: 900px;
      margin: 0 auto;
      line-height: 1.5;
    }

    .btn-wrapper {

      text-align: center;
    }

    .btn-wrapper a {
      font-family: Cerebri Sans, Helvetica, Arial, sans-serif;
      border: 1px solid #885DF1;
      font-size: 16px;
      padding: 16px 24px;
      color: #885DF1;
      text-decoration: none;
      margin: 20px 0;
      display: inline-block;
      border-radius: 30px;
      transition: all 150ms ease-in-out;
    }

    .btn-wrapper a:hover {
      background-color: #885DF1;
      color: #fff;
    }
  </style>
</head>
<body>
  <img src="/404.png" alt="">
  <h1>The page you were looking for doesn't exist</h1>

  <p>
    You may have mistyped the address or the page may have moved. If you are the application owner check the logs for more information.
  </p>
  <div class="btn-wrapper">
    <a href="/">Back to homepage</a>
  </div>
</body>
</html>
